<?php
session_start();
require_once __DIR__ . '/../config/database.php';

if (isset($_SESSION['login'])) {
    header("Location: ../dashboard/index.php");
    exit;
}

$error = '';

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    $result = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");

    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row['password'])) {
            $_SESSION['login']    = true;
            $_SESSION['username'] = $row['username'];
            $_SESSION['nama']     = $row['nama'];

            header("Location: ../dashboard/index.php");
            exit;
        }
    }
    $error = "Username atau Password salah!";
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="login-body">

    <div class="login-card">
        <!-- Header & Sapaan Selamat Datang -->
        <div class="login-header">
            <span class="welcome-badge">👋 Selamat Datang!</span>
            <h2>LOGIN ADMIN</h2>
            <p>Silakan masukkan akun kamu untuk mengakses dashboard</p>
        </div>

        <!-- Alert Error Terapikkan -->
        <?php if ($error): ?>
            <div class="alert alert-error">
                ⚠️ <?= $error; ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" id="loginForm">
            <div class="form-group">
                <label for="username">Username / Email</label>
                <input type="text" name="username" id="username" placeholder="Masukkan username" required autocomplete="off">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" placeholder="••••••••" required>
            </div>
            <button type="submit" name="login" class="btn-primary">Masuk ke System 🚀</button>
        </form>
    </div>

    <script src="../assets/js/login.js"></script>
</body>

</html>