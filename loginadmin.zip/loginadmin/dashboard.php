<?php
session_start();
require 'koneksi.php';

// Cek status login
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

$pesan = '';

// 1. FITUR TAMBAH USER (Data Pengguna)
if (isset($_POST['tambah_user'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $nama     = mysqli_real_escape_string($conn, $_POST['nama']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $check = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");
    if (mysqli_num_rows($check) > 0) {
        $pesan = "error:Username '$username' sudah dipakai!";
    } else {
        $insert = mysqli_query($conn, "INSERT INTO users (username, password, nama) VALUES ('$username', '$password', '$nama')");
        if ($insert) {
            $pesan = "success:User baru berhasil ditambahkan!";
        } else {
            $pesan = "error:Gagal menambah user!";
        }
    }
}

// 2. FITUR EDIT USER (Data Pengguna)
if (isset($_POST['edit_user'])) {
    $id       = (int)$_POST['id_user'];
    $nama     = mysqli_real_escape_string($conn, $_POST['nama']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);

    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $query = "UPDATE users SET nama='$nama', username='$username', password='$password' WHERE id=$id";
    } else {
        $query = "UPDATE users SET nama='$nama', username='$username' WHERE id=$id";
    }

    if (mysqli_query($conn, $query)) {
        // Jika yang diedit adalah akun sendiri, perbarui session
        if ($username === $_SESSION['username']) {
            $_SESSION['nama'] = $nama;
        }
        $pesan = "success:Data user berhasil diperbarui!";
    } else {
        $pesan = "error:Gagal memperbarui data!";
    }
}

// 3. FITUR HAPUS USER (Data Pengguna)
if (isset($_GET['hapus'])) {
    $id_hapus = (int)$_GET['hapus'];
    $current_user = $_SESSION['username'];

    $check_user = mysqli_query($conn, "SELECT username FROM users WHERE id=$id_hapus");
    $data = mysqli_fetch_assoc($check_user);

    if ($data && $data['username'] === $current_user) {
        $pesan = "error:Kamu tidak bisa menghapus akunmu sendiri yang sedang aktif!";
    } else {
        mysqli_query($conn, "DELETE FROM users WHERE id = $id_hapus");
        header("Location: dashboard.php");
        exit;
    }
}

// 4. FITUR UPDATE PROFIL DARI MENU PENGATURAN
if (isset($_POST['update_profil'])) {
    $nama_baru = mysqli_real_escape_string($conn, $_POST['nama_profil']);
    $user_curr = $_SESSION['username'];

    if (!empty($_POST['password_baru'])) {
        $pass_hash = password_hash($_POST['password_baru'], PASSWORD_DEFAULT);
        $u_query = "UPDATE users SET nama='$nama_baru', password='$pass_hash' WHERE username='$user_curr'";
    } else {
        $u_query = "UPDATE users SET nama='$nama_baru' WHERE username='$user_curr'";
    }

    if (mysqli_query($conn, $u_query)) {
        $_SESSION['nama'] = $nama_baru;
        $pesan = "success:Profil berhasil diperbarui menjadi '$nama_baru'!";
    } else {
        $pesan = "error:Gagal mengupdate profil!";
    }
}

// Baca Data Users dari MySQL
$usersData = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
$totalUsers = mysqli_num_rows($usersData);
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin Interactive</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Roboto, sans-serif;
        }

        body {
            background-color: #f0f3fb;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling Jumbo */
        .sidebar {
            width: 320px;
            background: linear-gradient(180deg, #4158D0 0%, #C850C0 50%, #FFCC70 100%);
            color: white;
            padding: 40px 25px;
        }

        .sidebar h2 {
            font-size: 32px;
            font-weight: 900;
            letter-spacing: 2px;
            margin-bottom: 50px;
            text-shadow: 0 3px 6px rgba(0, 0, 0, 0.2);
        }

        .sidebar ul {
            list-style: none;
        }

        .sidebar ul li {
            margin-bottom: 18px;
        }

        .sidebar ul li a {
            color: white;
            text-decoration: none;
            font-size: 20px;
            font-weight: 700;
            display: block;
            padding: 18px 24px;
            border-radius: 16px;
            background: rgba(255, 255, 255, 0.18);
            backdrop-filter: blur(8px);
            transition: 0.3s;
            cursor: pointer;
        }

        .sidebar ul li a:hover,
        .sidebar ul li a.active {
            background: white;
            color: #C850C0;
            transform: translateX(10px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        /* Main Content Jumbo */
        .main-content {
            flex: 1;
            padding: 45px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            padding: 30px 40px;
            border-radius: 24px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            margin-bottom: 40px;
        }

        .header h1 {
            font-size: 42px;
            font-weight: 900;
            color: #2c3e50;
        }

        /* Stat Cards */
        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 30px;
            margin-bottom: 45px;
        }

        .card-box {
            padding: 35px;
            border-radius: 24px;
            color: white;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.12);
            transition: 0.3s;
        }

        .card-box:hover {
            transform: translateY(-10px);
        }

        .card-1 {
            background: linear-gradient(135deg, #FF6B6B, #FF8E53);
        }

        .card-2 {
            background: linear-gradient(135deg, #4E65FF, #92EFFD);
        }

        .card-3 {
            background: linear-gradient(135deg, #11998e, #38ef7d);
        }

        .card-4 {
            background: linear-gradient(135deg, #FC466B, #3F5EFB);
        }

        .card-box h3 {
            font-size: 56px;
            font-weight: 900;
            line-height: 1;
            margin-bottom: 12px;
        }

        .card-box p {
            font-size: 20px;
            font-weight: 800;
            opacity: 0.95;
            letter-spacing: 1px;
        }

        /* Card Section Body */
        .content-card {
            background: white;
            padding: 40px;
            border-radius: 24px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .table-header h2 {
            font-size: 32px;
            font-weight: 900;
            color: #2c3e50;
        }

        /* Table Styling Jumbo */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        table th {
            background: #f8f9fe;
            color: #444;
            font-size: 20px;
            font-weight: 800;
            text-align: left;
            padding: 22px;
            border-bottom: 4px solid #edf2f7;
        }

        table td {
            padding: 22px;
            font-size: 20px;
            font-weight: 600;
            color: #333;
            border-bottom: 1px solid #edf2f7;
        }

        table tr:hover {
            background-color: #fbfbfe;
        }

        /* Form Inputs in Settings */
        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            font-size: 20px;
            font-weight: 800;
            color: #333;
            margin-bottom: 10px;
        }

        .form-group input {
            width: 100%;
            max-width: 600px;
            padding: 18px 20px;
            border: 3px solid #e1e1e1;
            border-radius: 14px;
            font-size: 18px;
            font-weight: 700;
            outline: none;
        }

        .form-group input:focus {
            border-color: #4158D0;
        }

        /* Tombol-Tombol */
        .btn-add,
        .btn-save-setting {
            background: linear-gradient(135deg, #11998e, #38ef7d);
            color: white;
            padding: 16px 32px;
            border-radius: 16px;
            border: none;
            font-size: 20px;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(56, 239, 125, 0.4);
            transition: 0.3s;
        }

        .btn-add:hover,
        .btn-save-setting:hover {
            transform: scale(1.03);
        }

        .btn-edit {
            background: #ffb142;
            color: white;
            padding: 10px 20px;
            border-radius: 10px;
            border: none;
            font-size: 16px;
            font-weight: 800;
            cursor: pointer;
            margin-right: 8px;
        }

        .btn-edit:hover {
            background: #cc8e35;
        }

        .btn-delete {
            background: #ff4757;
            color: white;
            padding: 10px 20px;
            border-radius: 10px;
            text-decoration: none;
            font-size: 16px;
            font-weight: 800;
            transition: 0.2s;
        }

        .btn-delete:hover {
            background: #d63031;
        }

        .btn-logout {
            background: #ff4757;
            color: white;
            padding: 16px 32px;
            border-radius: 16px;
            border: none;
            font-size: 20px;
            font-weight: 800;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-logout:hover {
            background: #ff6b81;
            box-shadow: 0 8px 20px rgba(255, 71, 87, 0.4);
        }

        .alert {
            padding: 20px 25px;
            border-radius: 16px;
            font-size: 20px;
            font-weight: 800;
            margin-bottom: 30px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
        }

        /* Halaman Tab Section */
        .tab-section {
            display: none;
        }

        .tab-section.active {
            display: block;
        }

        /* Pop-up Modals Jumbo */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(6px);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 999;
        }

        .modal-card {
            background: white;
            padding: 45px;
            border-radius: 28px;
            width: 500px;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
            animation: popup 0.3s ease-out;
        }

        @keyframes popup {
            from {
                transform: scale(0.8);
                opacity: 0;
            }

            to {
                transform: scale(1);
                opacity: 1;
            }
        }

        .modal-card h3 {
            font-size: 30px;
            font-weight: 900;
            margin-bottom: 25px;
            color: #333;
        }

        .modal-card input {
            width: 100%;
            padding: 18px 20px;
            margin-bottom: 20px;
            border: 3px solid #e1e1e1;
            border-radius: 14px;
            font-size: 18px;
            font-weight: 700;
            outline: none;
        }

        .modal-card input:focus {
            border-color: #4158D0;
        }

        .modal-actions {
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            margin-top: 15px;
        }

        .btn-cancel {
            background: #e4e6eb;
            color: #333;
            padding: 14px 28px;
            border-radius: 12px;
            border: none;
            font-size: 18px;
            font-weight: 800;
            cursor: pointer;
        }

        .btn-save {
            background: #4158D0;
            color: white;
            padding: 14px 28px;
            border-radius: 12px;
            border: none;
            font-size: 18px;
            font-weight: 800;
            cursor: pointer;
        }
    </style>
</head>

<body>

    <!-- Sidebar Interaktif -->
    <div class="sidebar">
        <h2>ADMIN PANEL</h2>
        <ul>
            <li><a class="nav-link active" onclick="switchTab('dashboard')">Dashboard</a></li>
            <li><a class="nav-link" onclick="switchTab('pengguna')">Data Pengguna</a></li>
            <li><a class="nav-link" onclick="switchTab('laporan')">Laporan</a></li>
            <li><a class="nav-link" onclick="switchTab('pengaturan')">Pengaturan</a></li>
        </ul>
    </div>

    <!-- Main Content Area -->
    <div class="main-content">

        <!-- Header -->
        <div class="header">
            <h1>Halo, <?= htmlspecialchars($_SESSION['nama']); ?>! 👋</h1>
            <button class="btn-logout" onclick="openLogoutModal()">Logout</button>
        </div>

        <!-- Alert Notifikasi -->
        <?php if ($pesan):
            $parts = explode(':', $pesan);
            $type  = $parts[0] == 'success' ? 'alert-success' : 'alert-error';
            $text  = $parts[1];
        ?>
            <div class="alert <?= $type; ?>"><?= $text; ?></div>
        <?php endif; ?>

        <!-- ================= TAB 1: DASHBOARD ================= -->
        <div id="tab-dashboard" class="tab-section active">
            <div class="cards">
                <div class="card-box card-1">
                    <h3><?= $totalUsers; ?></h3>
                    <p>TOTAL USER (MySQL)</p>
                </div>
                <div class="card-box card-2">
                    <h3>Rp 24.8M</h3>
                    <p>TOTAL PENDAPATAN</p>
                </div>
                <div class="card-box card-3">
                    <h3>582</h3>
                    <p>TRANSAKSI HARI INI</p>
                </div>
                <div class="card-box card-4">
                    <h3>99.9%</h3>
                    <p>SERVER UPTIME</p>
                </div>
            </div>

            <div class="content-card">
                <h2 style="font-size: 30px; font-weight: 900; margin-bottom: 15px; color: #2c3e50;">Selamat Datang di System Control Panel</h2>
                <p style="font-size: 20px; color: #555; line-height: 1.6;">
                    Gunakan menu di samping kiri untuk mengelola data akun pengguna, melihat laporan harian, atau mengubah profil kamu.
                </p>
            </div>
        </div>

        <!-- ================= TAB 2: DATA PENGGUNA (CRUD) ================= -->
        <div id="tab-pengguna" class="tab-section">
            <div class="content-card">
                <div class="table-header">
                    <h2>Kelola Pengguna Sistem</h2>
                    <button class="btn-add" onclick="openAddModal()">+ Tambah Pengguna</button>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NAMA LENGKAP</th>
                            <th>USERNAME</th>
                            <th>AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        mysqli_data_seek($usersData, 0); // Reset pointer loop
                        while ($row = mysqli_fetch_assoc($usersData)):
                        ?>
                            <tr>
                                <td><strong>#<?= $row['id']; ?></strong></td>
                                <td><?= htmlspecialchars($row['nama']); ?></td>
                                <td><span style="color: #4158D0; font-weight: 800;">@<?= htmlspecialchars($row['username']); ?></span></td>
                                <td>
                                    <button class="btn-edit" onclick="openEditModal(<?= $row['id']; ?>, '<?= htmlspecialchars($row['nama']); ?>', '<?= htmlspecialchars($row['username']); ?>')">Edit</button>

                                    <?php if ($row['username'] !== $_SESSION['username']): ?>
                                        <a href="dashboard.php?hapus=<?= $row['id']; ?>" class="btn-delete" onclick="return confirm('Yakin ingin menghapus user ini?')">Hapus</a>
                                    <?php else: ?>
                                        <span style="color: #aaa; font-size: 16px;">(Sedang Aktif)</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ================= TAB 3: LAPORAN ================= -->
        <div id="tab-laporan" class="tab-section">
            <div class="content-card">
                <div class="table-header">
                    <h2>Laporan Transaksi & Keuangan</h2>
                    <button class="btn-add" onclick="window.print()">🖨️ Cetak Laporan</button>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>NO TRANSAKSI</th>
                            <th>TANGGAL</th>
                            <th>KATEGORI</th>
                            <th>JUMLAH</th>
                            <th>STATUS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>#TRX-9901</td>
                            <td>24 Sep 2026</td>
                            <td>Langganan Premium</td>
                            <td style="color: #11998e; font-weight: 800;">+ Rp 1.500.000</td>
                            <td><span style="background: #d4edda; color: #155724; padding: 6px 12px; border-radius: 8px; font-weight: 800;">BERHASIL</span></td>
                        </tr>
                        <tr>
                            <td>#TRX-9902</td>
                            <td>24 Sep 2026</td>
                            <td>Pembelian Lisensi</td>
                            <td style="color: #11998e; font-weight: 800;">+ Rp 3.200.000</td>
                            <td><span style="background: #d4edda; color: #155724; padding: 6px 12px; border-radius: 8px; font-weight: 800;">BERHASIL</span></td>
                        </tr>
                        <tr>
                            <td>#TRX-9903</td>
                            <td>23 Sep 2026</td>
                            <td>Maintenance Server</td>
                            <td style="color: #ff4757; font-weight: 800;">- Rp 450.000</td>
                            <td><span style="background: #fff3cd; color: #856404; padding: 6px 12px; border-radius: 8px; font-weight: 800;">PENDING</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ================= TAB 4: PENGATURAN ================= -->
        <div id="tab-pengaturan" class="tab-section">
            <div class="content-card">
                <h2 style="font-size: 32px; font-weight: 900; margin-bottom: 25px; color: #2c3e50;">Pengaturan Akun Saya</h2>
                <form action="" method="POST">
                    <div class="form-group">
                        <label>Nama Pengguna (Ubah ke "Admin Elda" di sini)</label>
                        <input type="text" name="nama_profil" value="<?= htmlspecialchars($_SESSION['nama']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Username (Aktif)</label>
                        <input type="text" value="<?= htmlspecialchars($_SESSION['username']); ?>" disabled style="background: #e9ecef;">
                    </div>
                    <div class="form-group">
                        <label>Password Baru (Kosongkan jika tidak mau ganti)</label>
                        <input type="password" name="password_baru" placeholder="Masukkan password baru">
                    </div>
                    <button type="submit" name="update_profil" class="btn-save-setting">Simpan Perubahan Profil</button>
                </form>
            </div>
        </div>

    </div>

    <!-- Modal Tambah User -->
    <div class="modal-overlay" id="addModal">
        <div class="modal-card">
            <h3>Tambah User Baru</h3>
            <form action="" method="POST">
                <input type="text" name="nama" placeholder="Nama Lengkap" required>
                <input type="text" name="username" placeholder="Username" required autocomplete="off">
                <input type="password" name="password" placeholder="Password" required>
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeAddModal()">Batal</button>
                    <button type="submit" name="tambah_user" class="btn-save">Simpan Data</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Edit User -->
    <div class="modal-overlay" id="editModal">
        <div class="modal-card">
            <h3>Edit Data User</h3>
            <form action="" method="POST">
                <input type="hidden" name="id_user" id="edit_id">
                <input type="text" name="nama" id="edit_nama" placeholder="Nama Lengkap" required>
                <input type="text" name="username" id="edit_username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password Baru (Kosongkan jika tidak diubah)">
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeEditModal()">Batal</button>
                    <button type="submit" name="edit_user" class="btn-save">Update Data</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Logout -->
    <div class="modal-overlay" id="logoutModal">
        <div class="modal-card" style="text-align: center;">
            <h3 style="font-size: 32px;">Konfirmasi Logout</h3>
            <p style="color: #666; font-size: 20px; margin-bottom: 30px;">Apakah kamu yakin ingin keluar dari sistem?</p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <button class="btn-cancel" onclick="closeLogoutModal()">Batal</button>
                <a href="logout.php" style="background: #ff4757; color: white; padding: 14px 28px; border-radius: 12px; text-decoration: none; font-weight: 800; font-size: 18px;">Ya, Logout</a>
            </div>
        </div>
    </div>

    <script>
        // Fungsi Pindah Tab Sidebar
        function switchTab(tabName) {
            // Sembunyikan semua section
            document.querySelectorAll('.tab-section').forEach(sec => sec.classList.remove('active'));
            // Hapus class active dari semua tombol sidebar
            document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));

            // Tampilkan section yang dipilih
            document.getElementById('tab-' + tabName).classList.add('active');

            // Set tombol sidebar yang diklik jadi active
            event.target.classList.add('active');
        }

        function openAddModal() {
            document.getElementById('addModal').style.display = 'flex';
        }

        function closeAddModal() {
            document.getElementById('addModal').style.display = 'none';
        }

        function openEditModal(id, nama, username) {
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_nama').value = nama;
            document.getElementById('edit_username').value = username;
            document.getElementById('editModal').style.display = 'flex';
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        function openLogoutModal() {
            document.getElementById('logoutModal').style.display = 'flex';
        }

        function closeLogoutModal() {
            document.getElementById('logoutModal').style.display = 'none';
        }
    </script>
</body>

</html>