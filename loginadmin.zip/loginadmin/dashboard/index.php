<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Cek status login
if (!isset($_SESSION['login'])) {
    header("Location: ../auth/login.php");
    exit;
}

$pesan = '';

// FITUR TAMBAH USER
if (isset($_POST['tambah_user'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $nama     = mysqli_real_escape_string($conn, $_POST['nama']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $check = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");
    if (mysqli_num_rows($check) > 0) {
        $pesan = "error:Username '$username' sudah dipakai!";
    } else {
        $insert = mysqli_query($conn, "INSERT INTO users (username, password, nama) VALUES ('$username', '$password', '$nama')");
        if ($insert) {
            $pesan = "success:User baru berhasil ditambahkan!";
        } else {
            $pesan = "error:Gagal menambah user!";
        }
    }
}

// FITUR EDIT USER
if (isset($_POST['edit_user'])) {
    $id       = (int)$_POST['id_user'];
    $nama     = mysqli_real_escape_string($conn, $_POST['nama']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);

    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $query = "UPDATE users SET nama='$nama', username='$username', password='$password' WHERE id=$id";
    } else {
        $query = "UPDATE users SET nama='$nama', username='$username' WHERE id=$id";
    }

    if (mysqli_query($conn, $query)) {
        if ($username === $_SESSION['username']) {
            $_SESSION['nama'] = $nama;
        }
        $pesan = "success:Data user berhasil diperbarui!";
    } else {
        $pesan = "error:Gagal memperbarui data!";
    }
}

// FITUR HAPUS USER
if (isset($_GET['hapus'])) {
    $id_hapus = (int)$_GET['hapus'];
    $current_user = $_SESSION['username'];

    $check_user = mysqli_query($conn, "SELECT username FROM users WHERE id=$id_hapus");
    $data = mysqli_fetch_assoc($check_user);

    if ($data && $data['username'] === $current_user) {
        $pesan = "error:Kamu tidak bisa menghapus akunmu sendiri yang sedang aktif!";
    } else {
        mysqli_query($conn, "DELETE FROM users WHERE id = $id_hapus");
        header("Location: index.php");
        exit;
    }
}

// FITUR UPDATE PROFIL (Pengaturan)
if (isset($_POST['update_profil'])) {
    $nama_baru = mysqli_real_escape_string($conn, $_POST['nama_profil']);
    $user_curr = $_SESSION['username'];

    if (!empty($_POST['password_baru'])) {
        $pass_hash = password_hash($_POST['password_baru'], PASSWORD_DEFAULT);
        $u_query = "UPDATE users SET nama='$nama_baru', password='$pass_hash' WHERE username='$user_curr'";
    } else {
        $u_query = "UPDATE users SET nama='$nama_baru' WHERE username='$user_curr'";
    }

    if (mysqli_query($conn, $u_query)) {
        $_SESSION['nama'] = $nama_baru;
        $pesan = "success:Profil berhasil diperbarui menjadi '$nama_baru'!";
    } else {
        $pesan = "error:Gagal mengupdate profil!";
    }
}

// Query Ambil User
$usersData = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
$totalUsers = mysqli_num_rows($usersData);
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="dashboard-body">

    <!-- Sidebar Interaktif -->
    <div class="sidebar">
        <h2>ADMIN PANEL</h2>
        <ul>
            <li><a class="nav-link active" onclick="switchTab('dashboard')">Dashboard</a></li>
            <li><a class="nav-link" onclick="switchTab('pengguna')">Data Pengguna</a></li>
            <li><a class="nav-link" onclick="switchTab('laporan')">Laporan</a></li>
            <li><a class="nav-link" onclick="switchTab('pengaturan')">Pengaturan</a></li>
        </ul>
    </div>

    <!-- Main Content Area -->
    <div class="main-content">

        <!-- Header -->
        <div class="header">
            <h1>Halo, <?= htmlspecialchars($_SESSION['nama']); ?>! 👋</h1>
            <button class="btn-logout" onclick="openLogoutModal()">Logout</button>
        </div>

        <!-- Alert Notifikasi -->
        <?php if ($pesan):
            $parts = explode(':', $pesan);
            $type  = $parts[0] == 'success' ? 'alert-success' : 'alert-error';
            $text  = $parts[1];
        ?>
            <div class="alert <?= $type; ?>"><?= $text; ?></div>
        <?php endif; ?>

        <!-- TAB 1: DASHBOARD -->
        <div id="tab-dashboard" class="tab-section active">
            <div class="cards">
                <div class="card-box card-1">
                    <h3><?= $totalUsers; ?></h3>
                    <p>TOTAL USER (MySQL)</p>
                </div>
                <div class="card-box card-2">
                    <h3>Rp 24.8M</h3>
                    <p>TOTAL PENDAPATAN</p>
                </div>
                <div class="card-box card-3">
                    <h3>582</h3>
                    <p>TRANSAKSI HARI INI</p>
                </div>
                <div class="card-box card-4">
                    <h3>99.9%</h3>
                    <p>SERVER UPTIME</p>
                </div>
            </div>

            <div class="content-card">
                <h2 style="font-size: 30px; font-weight: 900; margin-bottom: 15px; color: #2c3e50;">Selamat Datang di System Control Panel</h2>
                <p style="font-size: 20px; color: #555; line-height: 1.6;">
                    Gunakan menu di samping kiri untuk mengelola data akun pengguna, melihat laporan harian, atau mengubah profil kamu.
                </p>
            </div>
        </div>

        <!-- TAB 2: DATA PENGGUNA (CRUD) -->
        <div id="tab-pengguna" class="tab-section">
            <div class="content-card">
                <div class="table-header">
                    <h2>Kelola Pengguna Sistem</h2>
                    <button class="btn-add" onclick="openAddModal()">+ Tambah Pengguna</button>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NAMA LENGKAP</th>
                            <th>USERNAME</th>
                            <th>AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        mysqli_data_seek($usersData, 0);
                        while ($row = mysqli_fetch_assoc($usersData)):
                        ?>
                            <tr>
                                <td><strong>#<?= $row['id']; ?></strong></td>
                                <td><?= htmlspecialchars($row['nama']); ?></td>
                                <td><span style="color: #4158D0; font-weight: 800;">@<?= htmlspecialchars($row['username']); ?></span></td>
                                <td>
                                    <button class="btn-edit" onclick="openEditModal(<?= $row['id']; ?>, '<?= htmlspecialchars($row['nama']); ?>', '<?= htmlspecialchars($row['username']); ?>')">Edit</button>

                                    <?php if ($row['username'] !== $_SESSION['username']): ?>
                                        <a href="index.php?hapus=<?= $row['id']; ?>" class="btn-delete" onclick="return confirm('Yakin ingin menghapus user ini?')">Hapus</a>
                                    <?php else: ?>
                                        <span style="color: #aaa; font-size: 16px;">(Sedang Aktif)</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- TAB 3: LAPORAN -->
        <div id="tab-laporan" class="tab-section">
            <div class="content-card">
                <div class="table-header">
                    <h2>Laporan Transaksi & Keuangan</h2>
                    <button class="btn-add" onclick="window.print()">🖨️ Cetak Laporan</button>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>NO TRANSAKSI</th>
                            <th>TANGGAL</th>
                            <th>KATEGORI</th>
                            <th>JUMLAH</th>
                            <th>STATUS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>#TRX-9901</td>
                            <td>24 Sep 2026</td>
                            <td>Langganan Premium</td>
                            <td style="color: #11998e; font-weight: 800;">+ Rp 1.500.000</td>
                            <td><span style="background: #d4edda; color: #155724; padding: 6px 12px; border-radius: 8px; font-weight: 800;">BERHASIL</span></td>
                        </tr>
                        <tr>
                            <td>#TRX-9902</td>
                            <td>24 Sep 2026</td>
                            <td>Pembelian Lisensi</td>
                            <td style="color: #11998e; font-weight: 800;">+ Rp 3.200.000</td>
                            <td><span style="background: #d4edda; color: #155724; padding: 6px 12px; border-radius: 8px; font-weight: 800;">BERHASIL</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- TAB 4: PENGATURAN -->
        <div id="tab-pengaturan" class="tab-section">
            <div class="content-card">
                <h2 style="font-size: 32px; font-weight: 900; margin-bottom: 25px; color: #2c3e50;">Pengaturan Akun Saya</h2>
                <form action="" method="POST">
                    <div class="form-group">
                        <label>Nama Pengguna</label>
                        <input type="text" name="nama_profil" value="<?= htmlspecialchars($_SESSION['nama']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Username (Aktif)</label>
                        <input type="text" value="<?= htmlspecialchars($_SESSION['username']); ?>" disabled style="background: #e9ecef;">
                    </div>
                    <div class="form-group">
                        <label>Password Baru (Kosongkan jika tidak mau ganti)</label>
                        <input type="password" name="password_baru" placeholder="Masukkan password baru">
                    </div>
                    <button type="submit" name="update_profil" class="btn-save-setting">Simpan Perubahan Profil</button>
                </form>
            </div>
        </div>

    </div>

    <!-- Modal Tambah User -->
    <div class="modal-overlay" id="addModal">
        <div class="modal-card">
            <h3>Tambah User Baru</h3>
            <form action="" method="POST">
                <input type="text" name="nama" placeholder="Nama Lengkap" required>
                <input type="text" name="username" placeholder="Username" required autocomplete="off">
                <input type="password" name="password" placeholder="Password" required>
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeAddModal()">Batal</button>
                    <button type="submit" name="tambah_user" class="btn-save">Simpan Data</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Edit User -->
    <div class="modal-overlay" id="editModal">
        <div class="modal-card">
            <h3>Edit Data User</h3>
            <form action="" method="POST">
                <input type="hidden" name="id_user" id="edit_id">
                <input type="text" name="nama" id="edit_nama" placeholder="Nama Lengkap" required>
                <input type="text" name="username" id="edit_username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password Baru (Kosongkan jika tidak diubah)">
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeEditModal()">Batal</button>
                    <button type="submit" name="edit_user" class="btn-save">Update Data</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Logout -->
    <div class="modal-overlay" id="logoutModal">
        <div class="modal-card" style="text-align: center;">
            <h3 style="font-size: 32px;">Konfirmasi Logout</h3>
            <p style="color: #666; font-size: 20px; margin-bottom: 30px;">Apakah kamu yakin ingin keluar dari sistem?</p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <button class="btn-cancel" onclick="closeLogoutModal()">Batal</button>
                <a href="../auth/logout.php" style="background: #ff4757; color: white; padding: 14px 28px; border-radius: 12px; text-decoration: none; font-weight: 800; font-size: 18px;">Ya, Logout</a>
            </div>
        </div>
    </div>

    <script src="../assets/js/login.js"></script>
</body>

</html>